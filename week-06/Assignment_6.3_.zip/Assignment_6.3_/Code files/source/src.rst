src namespace
=============

.. py:module:: src

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.arithemetic
   src.calculator
   src.common
