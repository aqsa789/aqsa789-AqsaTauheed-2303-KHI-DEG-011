ERROR_VALUE = float(-1)
"""
ERROR_VALUE (float constant): The error value to be returned when input is not positive.
"""

